require 'test_helper'

class LikeHospitalTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
