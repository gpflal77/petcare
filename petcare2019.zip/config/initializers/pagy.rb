## config/initializers/pagy.rb
require 'pagy/extras/bootstrap'