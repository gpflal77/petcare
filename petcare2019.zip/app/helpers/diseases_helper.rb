module DiseasesHelper
end
