module PetsHelper
    include Pagy::Frontend
end
