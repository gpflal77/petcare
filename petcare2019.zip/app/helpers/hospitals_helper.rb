module HospitalsHelper
end
