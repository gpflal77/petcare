class Hospital < ApplicationRecord
   # has_many :like_hospitals
   # has_many :users, through: :like_hospitals
   
   IMAGE = ["iStock_000018813626XLarge.jpg", "Many_Pets.jpg", "0.jpg", "pet_exam_2.jpg", "slider-3.png", "images.jpg", "BluePearl-Chihuahua-Care-300x200.jpg", "Haban.jpg", "img-7421_2.jpg", "home-page-horizontal.png"]
end
