class Cost < ApplicationRecord
end
