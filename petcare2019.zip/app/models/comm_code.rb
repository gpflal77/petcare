class CommCode < ApplicationRecord
   # belongs_to :hospital
end
