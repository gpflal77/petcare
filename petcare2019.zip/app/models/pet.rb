class Pet < ApplicationRecord
  has_one_attached :photo_file
end
